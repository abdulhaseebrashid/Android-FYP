package net.javaguides.todo.service.impl;

import lombok.AllArgsConstructor;
import net.javaguides.todo.dto.EmployeeRequestDto;
import net.javaguides.todo.dto.EmployeeResponseDto;
import net.javaguides.todo.entity.Employee;
import net.javaguides.todo.entity.UserType;
import net.javaguides.todo.repository.EmployeeRepository;
import net.javaguides.todo.repository.UserTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final UserTypeRepository userTypeRepository;

    @Transactional
    public EmployeeResponseDto createEmployee(EmployeeRequestDto employeeRequestDto) {
        // Validate UserType
        UserType userType = userTypeRepository.findById(employeeRequestDto.getUserTypeId())
                .orElseThrow(() -> new RuntimeException("UserType not found"));

        // Create new employee
        Employee employee = new Employee();
        setEmployeeData(employee, employeeRequestDto, userType);

        // Save and return
        Employee savedEmployee = employeeRepository.save(employee);
        return mapToResponseDto(savedEmployee);
    }

    @Transactional(readOnly = true)
    public EmployeeResponseDto getEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with ID: " + id));
        return mapToResponseDto(employee);
    }

    @Transactional(readOnly = true)
    public List<EmployeeResponseDto> getAllEmployees() {
        return employeeRepository.findAll().stream()
                .map(this::mapToResponseDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public EmployeeResponseDto updateEmployee(Long id, EmployeeRequestDto employeeRequestDto) {
        // Find existing employee
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with ID: " + id));

        // Determine UserType
        UserType userType = employee.getUserType(); // Default to existing UserType
        if (employeeRequestDto.getUserTypeId() != null) {
            userType = userTypeRepository.findById(employeeRequestDto.getUserTypeId())
                    .orElseThrow(() -> new RuntimeException("UserType not found"));
        }

        // Partial update logic
        updateEmployeeFields(employee, employeeRequestDto, userType);

        // Save and return updated employee
        Employee updatedEmployee = employeeRepository.save(employee);
        return mapToResponseDto(updatedEmployee);
    }

    @Transactional
    public void deleteEmployee(Long id) {
        // Verify employee exists before deletion
        if (!employeeRepository.existsById(id)) {
            throw new RuntimeException("Employee not found with ID: " + id);
        }
        employeeRepository.deleteById(id);
    }

    private void updateEmployeeFields(Employee employee, EmployeeRequestDto dto, UserType userType) {
        // Selective update - only update fields that are non-null
        if (dto.getFirstName() != null) {
            employee.setFirstName(dto.getFirstName());
        }
        if (dto.getLastName() != null) {
            employee.setLastName(dto.getLastName());
        }
        if (dto.getEmail() != null) {
            employee.setEmail(dto.getEmail());
        }
        if (dto.getPhoneNumber() != null) {
            employee.setPhoneNumber(dto.getPhoneNumber());
        }
        if (dto.getUsername() != null) {
            employee.setUsername(dto.getUsername());
        }
        if (dto.getBirthDate() != null) {
            employee.setBirthDate(dto.getBirthDate());
        }
        if (dto.getHireDate() != null) {
            employee.setHireDate(dto.getHireDate());
        }
        if (dto.getTerminationDate() != null) {
            employee.setTerminationDate(dto.getTerminationDate());
        }
        if (dto.getAnnualSalary() != null) {
            employee.setAnnualSalary(dto.getAnnualSalary());
        }
        if (dto.getAdditionalInfo() != null) {
            employee.setAdditionalInfo(dto.getAdditionalInfo());
        }

        // Always update UserType
        employee.setUserType(userType);
    }

    private void setEmployeeData(Employee employee, EmployeeRequestDto dto, UserType userType) {
        employee.setFirstName(dto.getFirstName());
        employee.setLastName(dto.getLastName());
        employee.setEmail(dto.getEmail());
        employee.setPhoneNumber(dto.getPhoneNumber());
        employee.setUsername(dto.getUsername());
        employee.setBirthDate(dto.getBirthDate());
        employee.setHireDate(dto.getHireDate());
        employee.setTerminationDate(dto.getTerminationDate());
        employee.setAnnualSalary(dto.getAnnualSalary());
        employee.setAdditionalInfo(dto.getAdditionalInfo());
        employee.setUserType(userType);
    }

    private EmployeeResponseDto mapToResponseDto(Employee employee) {
        return new EmployeeResponseDto(
                employee.getId(),
                employee.getFirstName(),
                employee.getLastName(),
                employee.getEmail(),
                employee.getPhoneNumber(),
                employee.getUsername(),
                employee.getUserType().getTypeName(),
                employee.getBirthDate(),
                employee.getHireDate(),
                employee.getTerminationDate(),
                employee.getAnnualSalary(),
                employee.getAdditionalInfo()
        );
    }
}