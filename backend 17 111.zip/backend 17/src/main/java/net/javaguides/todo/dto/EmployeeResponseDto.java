package net.javaguides.todo.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeResponseDto {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String username;
    private String userType; // Display the user type name

    // ✅ Newly added fields
    private Date birthDate;
    private Date hireDate;
    private Date terminationDate;
    private Double annualSalary;
    private String additionalInfo;
}
