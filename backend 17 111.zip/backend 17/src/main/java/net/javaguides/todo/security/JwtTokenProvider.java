package net.javaguides.todo.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtTokenProvider {

    @Value("${app.jwt-secret}")
    private String jwtSecret;

    @Value("${app.jwt-expiration-milliseconds}")
    private long jwtExpirationDate;

    public String generateToken(String username) {
        return generateToken(username, null); // Call the new method with null as role
    }

    public String generateToken(String username, String role) {
        Date currentDate = new Date();
        Date expireDate = new Date(currentDate.getTime() + jwtExpirationDate);

        JwtBuilder builder = Jwts.builder()
                .setSubject(username)
                .setIssuedAt(currentDate)
                .setExpiration(expireDate)
                .signWith(key());

        // Add the username as a claim
        builder.claim("username", username);

        // If role is provided, add it as a claim
        if (role != null) {
            builder.claim("role", role);  // Optional: Multiple roles could be added as a list
        }

        return builder.compact();
    }

    private Key key() {
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
    }

    public String getUsernameFromJWT(String token) {
        try {
            Claims claims = Jwts.parser()
                    .setSigningKey(key())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();

            // Log the claims to see what's in the token
            System.out.println("JWT Claims: " + claims);

            // Retrieve the username from claims (can use getSubject if set as subject)
            String username = claims.getSubject();
            System.out.println("Extracted Username: " + username);
            return username;
        } catch (Exception e) {
            // Log the exception if there's an issue with parsing the token
            System.out.println("Error while extracting username: " + e.getMessage());
            return null;
        }
    }


    public boolean validateToken(String token) {
        try {
            Jwts.parser().setSigningKey(key()).build().parseClaimsJws(token);
            return true;
        } catch (MalformedJwtException | ExpiredJwtException | UnsupportedJwtException | IllegalArgumentException ex) {
            // You could log the exception here or return more specific messages for debugging
            return false;
        }
    }

}
